function replacetext (str){
  document.getElementById("text").innerHTML = str
}// fixed?
// yup, it fixed it. lol
// lol yay